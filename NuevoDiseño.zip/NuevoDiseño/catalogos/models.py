from django.db import models  # Importa las herramientas para crear modelos en Django

# Modelo para guardar estados de la república
class Estado(models.Model):
    nombre = models.CharField(max_length=100, unique=True)  # Nombre del estado, único (no puede repetirse)
    clave = models.CharField(max_length=3, unique=True)     # Clave del estado, también única
    creado = models.DateTimeField(auto_now_add=True)        # Fecha automática cuando se crea el registro

    def __str__(self):
        # Muestra nombre y clave del estado al imprimir el objeto
        return f"{self.nombre} ({self.clave})"
    

# Modelo para guardar poblaciones/municipios que pertenecen a un Estado
class Poblacion(models.Model):  # Crea una tabla dependiente de Estado

    estado = models.ForeignKey(
        Estado,                     # Se relaciona con el modelo Estado
        on_delete=models.CASCADE,   # Si se borra el estado, también se borran sus poblaciones
        related_name="poblaciones"  # Permite acceder a las poblaciones desde estado.poblaciones
    )
    nombre = models.CharField(max_length=100)  # Nombre de la población (máximo 100 caracteres)

    def __str__(self):
        # Muestra el nombre de la población junto con su estado
        return f"{self.nombre}({self.estado.nombre})"


# Modelo para colonias que pertenecen a una población
class Ciudad(models.Model):
    nombre = models.CharField(max_length=100)  # Nombre de la colonia
    poblacion = models.ForeignKey(
        Poblacion,                    # Se relaciona con el modelo Poblacion
        on_delete=models.CASCADE,     # Si se borra la población, se borran sus colonias
        related_name="ciudades"       # Permite acceder a las ciudades desde poblacion.ciudades
    )

    def __str__(self):
        # Al imprimir el objeto, solo muestra el nombre de la ciudad
        return self.nombre
