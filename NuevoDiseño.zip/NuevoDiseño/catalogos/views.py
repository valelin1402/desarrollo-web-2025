# Importa funciones para manejar vistas y respuestas
from django.shortcuts import render, redirect, get_object_or_404

# Importa los modelos que usaremos
from .models import Estado, Poblacion, Ciudad

# Importa los formularios basados en los modelos
from .forms import EstadoForm, PoblacionForm, CiudadForm

# Para devolver respuestas HTML simples
from django.http import HttpResponse


# VISTA DE PRUEBA
def hola_mundo(request):
    # Devuelve un texto HTML directamente
    return HttpResponse("<h1>Bienvenidos</h1>")

# ESTADOS

def estados_list(request):
    # Obtiene todos los estados registrados
    estados = Estado.objects.all()

    # Renderiza la plantilla y envía la lista de estados
    return render(request, 'estados_list.html', {'estados': estados})


def estado_create(request):
    # Crea el formulario; si se enviaron datos, los carga en el formulario
    form = EstadoForm(request.POST or None)

    # Si el formulario está correctamente llenado
    if form.is_valid():
        form.save()          # Guarda el estado nuevo
        return redirect('estados_list')   # Redirige al listado

    # Si no se ha enviado nada, muestra el form vacío
    return render(request, 'estados_form.html', {'form': form})


def estado_update(request, pk):
    # Obtiene el estado o devuelve error 404 si no existe
    estado = get_object_or_404(Estado, id=pk)

    # Crea el formulario con los datos enviados o con el estado existente
    form = EstadoForm(request.POST or None, instance=estado)

    # Si es válido, lo guarda
    if form.is_valid():
        form.save()
        return redirect('estados_list')

    # Muestra el formulario lleno con los datos actuales
    return render(request, 'estados_form.html', {'form': form})


def estado_delete(request, pk):
    # Busca el estado por ID
    estado = get_object_or_404(Estado, id=pk)

    # Si el usuario confirmó con POST
    if request.method == 'POST':
        estado.delete()     # Lo borra
        return redirect('estados_list')

    # Muestra la pantalla para confirmar la eliminación
    return render(request, 'estado_confirm_delete.html', {'estado': estado})

# POBLACIONES

def poblaciones_list(request):
    # Obtiene todas las poblaciones junto con su estado relacionado
    poblaciones = Poblacion.objects.select_related("estado",).all()

    # Envía los datos al template
    return render(request, "estados/poblaciones_list.html", {
        "poblaciones": poblaciones
    })

def poblaciones_por_estado(request, pk):
    # Obtiene el estado por ID
    estado = get_object_or_404(Estado, pk=pk)

    # Obtiene solo poblaciones de ese estado
    poblaciones = Poblacion.objects.filter(estado=estado)

    # Renderiza el listado
    return render(request, "estados/poblaciones_por_estado.html", {
        "estado": estado,
        "poblaciones": poblaciones
    })


def agregar_poblacion(request, pk):
    # Busca el estado al que se asignará la población
    estado = get_object_or_404(Estado, pk=pk)

    if request.method == "POST":
        # Carga los datos enviados al formulario
        form = PoblacionForm(request.POST)

        # Verifica si el formulario es válido
        if form.is_valid():
            # Crea la instancia sin guardarla aún
            poblacion = form.save(commit=False)

            # Asigna el estado automáticamente
            poblacion.estado = estado

            # Ahora sí la guarda
            poblacion.save()

            # Redirige a las poblaciones del estado
            return redirect("poblaciones_por_estado", pk=estado.pk)

    else:
        # Si es GET, formulario vacío
        form = PoblacionForm()

    # Muestra el formulario
    return render(request, "estados/poblacion_form.html",{
        "form": form,
        "estado": estado
    })


def editar_poblacion(request, pk):
    # Obtiene la población
    poblacion = get_object_or_404(Poblacion, pk=pk)

    # Obtiene su estado para redirigir luego
    estado = poblacion.estado

    if request.method == "POST":
        # Carga los datos en el formulario del objeto existente
        form = PoblacionForm(request.POST, instance=poblacion)

        if form.is_valid():
            form.save()
            return redirect("poblaciones_por_estado", pk=estado.pk)

    else:
        # Muestra el formulario lleno
        form = PoblacionForm(instance=poblacion)

    return render(request, "estados/poblacion_form.html",{
        "form": form,
        "estado": estado
    })


def eliminar_poblacion(request, pk):
    # Obtiene la población a borrar
    poblacion = get_object_or_404(Poblacion, pk=pk)

    estado = poblacion.estado  # Para redirigir después

    if request.method == "POST":
        poblacion.delete()  # Borra la población
        return redirect("poblaciones_por_estado", pk=estado.pk)

    # Pide confirmación
    return render(request, "estados/poblacion_confirm_delete.html",{
        "poblacion": poblacion
    })

# CIUDADES

def ciudades_list(request):
    # Obtiene todas las ciudades junto con su población y estado
    ciudades = Ciudad.objects.select_related("poblacion", "poblacion__estado").all()

    # Envía la lista de ciudades al template
    return render(request, "ciudades/ciudades_list.html", {
        "ciudades": ciudades
    })


def ciudades_por_poblacion(request, pk):
    # Busca la población con el ID recibido
    poblacion = get_object_or_404(Poblacion, pk=pk)

    # Obtiene todas las ciudades asociadas a esa población
    ciudades = Ciudad.objects.filter(poblacion=poblacion)

    # Envía la población y sus ciudades al template
    return render(request, "ciudades/ciudades_por_poblacion.html", {
        "poblacion": poblacion,
        "ciudades": ciudades
    })


def agregar_ciudad(request, pk):
    # Obtiene la población donde se añadirá la nueva ciudad
    poblacion = get_object_or_404(Poblacion, pk=pk)

    if request.method == "POST":
        # Carga los datos enviados por el formulario
        form = CiudadForm(request.POST)

        if form.is_valid():
            # Crea el objeto ciudad sin guardarlo aún
            ciudad = form.save(commit=False)

            # Asigna la población a la colonia
            ciudad.poblacion = poblacion

            ciudad.save()   # Guarda la colonia en la base de datos

            # Redirige al listado de colonia de esa población
            return redirect("ciudades_por_poblacion", pk=poblacion.pk)

    else:
        # Si es GET, muestra un formulario vacío
        form = CiudadForm()

    return render(request, "ciudades/ciudad_form.html", {
        "form": form,
        "poblacion": poblacion
    })


def editar_ciudad(request, pk):
    # Busca la colonia a editar
    ciudad = get_object_or_404(Ciudad, pk=pk)

    # Guarda la población para poder redirigir al terminar
    poblacion = ciudad.poblacion

    if request.method == "POST":
        # Carga los datos nuevos en el formulario usando la instancia actual
        form = CiudadForm(request.POST, instance=ciudad)

        if form.is_valid():
            form.save()  # Guarda los cambios
            return redirect("ciudades_por_poblacion", pk=poblacion.pk)

    else:
        # Si es GET, muestra el formulario con los datos actuales de la ciudad
        form = CiudadForm(instance=ciudad)

    return render(request, "ciudades/ciudad_form.html", {
        "form": form,
        "poblacion": poblacion
    })


def eliminar_ciudad(request, pk):
    # Obtiene la colonia que se desea borrar
    ciudad = get_object_or_404(Ciudad, pk=pk)

    # Guarda la población para volver al listado correcto después de eliminarla
    poblacion = ciudad.poblacion

    if request.method == "POST":
        ciudad.delete()  # Borra la colonia de la base de datos
        return redirect("ciudades_por_poblacion", pk=poblacion.pk)

    # Si es GET, solo muestra la confirmación
    return render(request, "ciudades/ciudad_confirm_delete.html", {
        "ciudad": ciudad
    })
