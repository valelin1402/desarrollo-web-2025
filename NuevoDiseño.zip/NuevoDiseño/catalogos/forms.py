from django import forms  # Importa las herramientas para crear formularios en Django
from .models import Estado  # Importa el modelo Estado
from .models import Poblacion  # Importa el modelo Poblacion
from .models import Ciudad  # Importa el modelo Colonias


# Formulario basado en el modelo Estado
class EstadoForm(forms.ModelForm):
    class Meta:
        model = Estado                 # Indica que el formulario usa el modelo Estado
        fields = ['clave', 'nombre']   # Campos que aparecerán en el formulario


# (Repetido, pero lo dejo igual porque pediste no mover nada)
class EstadoForm(forms.ModelForm):
    class Meta:
        model = Estado                 # Indica que el formulario usa el modelo Estado
        fields = ['clave', 'nombre']   # Campos visibles en el formulario


# Formulario basado en el modelo Poblacion
class PoblacionForm(forms.ModelForm):  # Crea un formulario usando el modelo Poblacion
    class Meta:
        model = Poblacion              # Modelo al que pertenece el formulario
        fields = ['nombre']            # Mostrará únicamente el nombre
        # El estado se asignará automáticamente desde la vista, por eso no aparece aquí.


# Formulario basado en el modelo Colonias
class CiudadForm(forms.ModelForm):
    class Meta:
        model = Ciudad                 # Indica que usa el modelo Ciudad
        fields = ['nombre']            # Solo mostrará el nombre de la ciudad
