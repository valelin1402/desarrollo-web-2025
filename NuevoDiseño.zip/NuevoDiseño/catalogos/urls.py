# Importa la función path para definir rutas
from django.urls import path

# Importa las vistas del mismo módulo
from . import views

# Importa vistas específicas desde catalogos.views
# (esto se hace para no escribir views.nombre_vista cuando ya las tienes separadas)
from catalogos.views import(
    poblaciones_por_estado,
    agregar_poblacion,
    editar_poblacion,
    eliminar_poblacion,
    ciudades_por_poblacion,
    agregar_ciudad,
    editar_ciudad,
    eliminar_ciudad

)

# Lista de rutas URL del sistema
urlpatterns = [ 

    # Ruta principal → muestra la vista hola_mundo
    path('', views.hola_mundo),

    #ESTADOS

    # LISTAR ESTADOS
    path('estados/', views.estados_list, name='estados_list'),

    # CREAR ESTADO
    path('estados/nuevo/', views.estado_create, name='estado_create'),

    # EDITAR ESTADO  recibe un ID (pk)
    path('estados/editar/<int:pk>/', views.estado_update, name='estado_update'),

    # ELIMINAR ESTADO  recibe un ID (pk)
    path('estados/delete/<int:pk>/', views.estado_delete, name='estado_delete'),

    #POBLACIONES

    # LISTAR POBLACIONES DE UN ESTADO  usa el id del estado
    path('estados/poblaciones/<int:pk>', views.poblaciones_por_estado, name="poblaciones_por_estado"),

    # LISTAR TODAS LAS POBLACIONES (sin importar el estado)    
    path('poblaciones/', views.poblaciones_list, name='poblaciones_list'),
  
    # AGREGAR POBLACIÓN A UN ESTADO (ruta principal)
    path('estados/<int:pk>/poblaciones/agregar/', agregar_poblacion, name="agregar_poblacion"),

    # EDITAR UNA POBLACIÓN → recibe el ID de la población
    path('estados/poblaciones/<int:pk>/editar/', editar_poblacion, name="editar_poblacion"),

    # ELIMINAR UNA POBLACIÓN → recibe el ID de la población
    path('estados/poblaciones/<int:pk>/eliminar/', eliminar_poblacion, name="eliminar_poblacion"),

    #COLONIAS

    # LISTAR COLONIAS DE UNA POBLACIÓN
    path('estados/poblaciones/<int:pk>/ciudades/', views.ciudades_por_poblacion, name="ciudades_por_poblacion"),

    # AGREGAR CIUDAD A UNA POBLACIÓN
    path('poblaciones/<int:pk>/ciudades/nuevo/', agregar_ciudad, name='agregar_ciudad'),

    # EDITAR CIUDAD
    path("estados/ciudades/<int:pk>/editar/", views.editar_ciudad, name="editar_ciudad"),

    # ELIMINAR CIUDAD
    path("estados/ciudades/<int:pk>/eliminar/", views.eliminar_ciudad, name="eliminar_ciudad"),

    # LISTAR TODAS LAS CIUDADES (todas juntas)
    path('ciudades/', views.ciudades_list, name='ciudades_list'),

    path('poblaciones/nuevo/', agregar_poblacion, name='agregar_poblacion'),
]
