from django.contrib import admin
from . models import Estado, Poblacion, Ciudad

# Esta clase permite mostrar Poblaciones dentro del admin de Estado.
# TabularInline muestra las poblaciones en forma de tabla.
class PoblacionInline(admin.TabularInline):  # Puedes usar admin.StackedInline para vista vertical
    model = Poblacion              # Indica el modelo relacionado
    extra = 1                      # Muestra 1 formulario vacío adicional para agregar rápido


# Admin para el modelo Estado
@admin.register(Estado)
class EstadoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "clave")  # Columnas que se mostrarán en la lista del admin
    inlines = [PoblacionInline]         # Permite gestionar poblaciones desde dentro del Estado


# Admin para el modelo Poblacion
@admin.register(Poblacion)
class PoblacionAdmin(admin.ModelAdmin):
    list_display = ("nombre", "estado")  # Muestra nombre de población y su estado


# Admin para el modelo Ciudad
@admin.register(Ciudad)
class CiudadAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'poblacion')  # Columnas en la tabla del admin
    list_filter = ('poblacion',)                  # Filtros laterales por población
    search_fields = ('nombre',)                   # Barra de búsqueda por nombre de colonia

